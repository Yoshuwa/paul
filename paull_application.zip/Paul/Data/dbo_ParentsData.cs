using System;
using System.Data;
using System.Data.SqlClient;
using Paul.Models;

namespace Paul.Data
{
    public class dbo_ParentsData
    {

        public static DataTable SelectAll()
        {
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement
                = "SELECT "  
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                + "";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.CommandType = CommandType.Text;
            DataTable dt = new DataTable();
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                if (reader.HasRows) {
                    dt.Load(reader); }
                reader.Close();
            }
            catch (SqlException)
            {
                return dt;
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static DataTable Search(string sField, string sCondition, string sValue)
        {
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement = "";
            if (sCondition == "Contains") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                    + "WHERE " 
                    + "     (@ParentID IS NULL OR @ParentID = '' OR [Parents].[ParentID] LIKE '%' + LTRIM(RTRIM(@ParentID)) + '%') " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Parents].[Name] LIKE '%' + LTRIM(RTRIM(@Name)) + '%') " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Parents].[Surname] LIKE '%' + LTRIM(RTRIM(@Surname)) + '%') " 
                    + "AND   (@PhoneNumber IS NULL OR @PhoneNumber = '' OR [Parents].[PhoneNumber] LIKE '%' + LTRIM(RTRIM(@PhoneNumber)) + '%') " 
                    + "AND   (@EmailAddress IS NULL OR @EmailAddress = '' OR [Parents].[EmailAddress] LIKE '%' + LTRIM(RTRIM(@EmailAddress)) + '%') " 
                    + "AND   (@Address IS NULL OR @Address = '' OR [Parents].[Address] LIKE '%' + LTRIM(RTRIM(@Address)) + '%') " 
                    + "AND   (@Description IS NULL OR @Description = '' OR [Parents].[Description] LIKE '%' + LTRIM(RTRIM(@Description)) + '%') " 
                    + "";
            } else if (sCondition == "Equals") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                    + "WHERE " 
                    + "     (@ParentID IS NULL OR @ParentID = '' OR [Parents].[ParentID] = LTRIM(RTRIM(@ParentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Parents].[Name] = LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Parents].[Surname] = LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@PhoneNumber IS NULL OR @PhoneNumber = '' OR [Parents].[PhoneNumber] = LTRIM(RTRIM(@PhoneNumber))) " 
                    + "AND   (@EmailAddress IS NULL OR @EmailAddress = '' OR [Parents].[EmailAddress] = LTRIM(RTRIM(@EmailAddress))) " 
                    + "AND   (@Address IS NULL OR @Address = '' OR [Parents].[Address] = LTRIM(RTRIM(@Address))) " 
                    + "AND   (@Description IS NULL OR @Description = '' OR [Parents].[Description] = LTRIM(RTRIM(@Description))) " 
                    + "";
            } else if  (sCondition == "Starts with...") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                    + "WHERE " 
                    + "     (@ParentID IS NULL OR @ParentID = '' OR [Parents].[ParentID] LIKE LTRIM(RTRIM(@ParentID)) + '%') " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Parents].[Name] LIKE LTRIM(RTRIM(@Name)) + '%') " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Parents].[Surname] LIKE LTRIM(RTRIM(@Surname)) + '%') " 
                    + "AND   (@PhoneNumber IS NULL OR @PhoneNumber = '' OR [Parents].[PhoneNumber] LIKE LTRIM(RTRIM(@PhoneNumber)) + '%') " 
                    + "AND   (@EmailAddress IS NULL OR @EmailAddress = '' OR [Parents].[EmailAddress] LIKE LTRIM(RTRIM(@EmailAddress)) + '%') " 
                    + "AND   (@Address IS NULL OR @Address = '' OR [Parents].[Address] LIKE LTRIM(RTRIM(@Address)) + '%') " 
                    + "AND   (@Description IS NULL OR @Description = '' OR [Parents].[Description] LIKE LTRIM(RTRIM(@Description)) + '%') " 
                    + "";
            } else if  (sCondition == "More than...") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                    + "WHERE " 
                    + "     (@ParentID IS NULL OR @ParentID = '' OR [Parents].[ParentID] > LTRIM(RTRIM(@ParentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Parents].[Name] > LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Parents].[Surname] > LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@PhoneNumber IS NULL OR @PhoneNumber = '' OR [Parents].[PhoneNumber] > LTRIM(RTRIM(@PhoneNumber))) " 
                    + "AND   (@EmailAddress IS NULL OR @EmailAddress = '' OR [Parents].[EmailAddress] > LTRIM(RTRIM(@EmailAddress))) " 
                    + "AND   (@Address IS NULL OR @Address = '' OR [Parents].[Address] > LTRIM(RTRIM(@Address))) " 
                    + "AND   (@Description IS NULL OR @Description = '' OR [Parents].[Description] > LTRIM(RTRIM(@Description))) " 
                    + "";
            } else if  (sCondition == "Less than...") {
                selectStatement
                    = "SELECT " 
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                    + "WHERE " 
                    + "     (@ParentID IS NULL OR @ParentID = '' OR [Parents].[ParentID] < LTRIM(RTRIM(@ParentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Parents].[Name] < LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Parents].[Surname] < LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@PhoneNumber IS NULL OR @PhoneNumber = '' OR [Parents].[PhoneNumber] < LTRIM(RTRIM(@PhoneNumber))) " 
                    + "AND   (@EmailAddress IS NULL OR @EmailAddress = '' OR [Parents].[EmailAddress] < LTRIM(RTRIM(@EmailAddress))) " 
                    + "AND   (@Address IS NULL OR @Address = '' OR [Parents].[Address] < LTRIM(RTRIM(@Address))) " 
                    + "AND   (@Description IS NULL OR @Description = '' OR [Parents].[Description] < LTRIM(RTRIM(@Description))) " 
                    + "";
            } else if  (sCondition == "Equal or more than...") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                    + "WHERE " 
                    + "     (@ParentID IS NULL OR @ParentID = '' OR [Parents].[ParentID] >= LTRIM(RTRIM(@ParentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Parents].[Name] >= LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Parents].[Surname] >= LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@PhoneNumber IS NULL OR @PhoneNumber = '' OR [Parents].[PhoneNumber] >= LTRIM(RTRIM(@PhoneNumber))) " 
                    + "AND   (@EmailAddress IS NULL OR @EmailAddress = '' OR [Parents].[EmailAddress] >= LTRIM(RTRIM(@EmailAddress))) " 
                    + "AND   (@Address IS NULL OR @Address = '' OR [Parents].[Address] >= LTRIM(RTRIM(@Address))) " 
                    + "AND   (@Description IS NULL OR @Description = '' OR [Parents].[Description] >= LTRIM(RTRIM(@Description))) " 
                    + "";
            } else if (sCondition == "Equal or less than...") {
                selectStatement 
                    = "SELECT "
                + "     [dbo].[Parents].[ParentID] "
                + "    ,[dbo].[Parents].[Name] "
                + "    ,[dbo].[Parents].[Surname] "
                + "    ,[dbo].[Parents].[PhoneNumber] "
                + "    ,[dbo].[Parents].[EmailAddress] "
                + "    ,[dbo].[Parents].[Address] "
                + "    ,[dbo].[Parents].[Description] "
                + "FROM " 
                + "     [dbo].[Parents] " 
                    + "WHERE " 
                    + "     (@ParentID IS NULL OR @ParentID = '' OR [Parents].[ParentID] <= LTRIM(RTRIM(@ParentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Parents].[Name] <= LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Parents].[Surname] <= LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@PhoneNumber IS NULL OR @PhoneNumber = '' OR [Parents].[PhoneNumber] <= LTRIM(RTRIM(@PhoneNumber))) " 
                    + "AND   (@EmailAddress IS NULL OR @EmailAddress = '' OR [Parents].[EmailAddress] <= LTRIM(RTRIM(@EmailAddress))) " 
                    + "AND   (@Address IS NULL OR @Address = '' OR [Parents].[Address] <= LTRIM(RTRIM(@Address))) " 
                    + "AND   (@Description IS NULL OR @Description = '' OR [Parents].[Description] <= LTRIM(RTRIM(@Description))) " 
                    + "";
            }
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.CommandType = CommandType.Text;
            if (sField == "Parent I D") {
                selectCommand.Parameters.AddWithValue("@ParentID", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@ParentID", DBNull.Value); }
            if (sField == "Name") {
                selectCommand.Parameters.AddWithValue("@Name", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@Name", DBNull.Value); }
            if (sField == "Surname") {
                selectCommand.Parameters.AddWithValue("@Surname", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@Surname", DBNull.Value); }
            if (sField == "Phone Number") {
                selectCommand.Parameters.AddWithValue("@PhoneNumber", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@PhoneNumber", DBNull.Value); }
            if (sField == "Email Address") {
                selectCommand.Parameters.AddWithValue("@EmailAddress", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@EmailAddress", DBNull.Value); }
            if (sField == "Address") {
                selectCommand.Parameters.AddWithValue("@Address", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@Address", DBNull.Value); }
            if (sField == "Description") {
                selectCommand.Parameters.AddWithValue("@Description", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@Description", DBNull.Value); }
            DataTable dt = new DataTable();
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                if (reader.HasRows) {
                    dt.Load(reader); }
                reader.Close();
            }
            catch (SqlException)
            {
                return dt;
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static dbo_Parents Select_Record(dbo_Parents dbo_ParentsPara)
        {
        dbo_Parents dbo_Parents = new dbo_Parents();
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement
            = "SELECT " 
                + "     [ParentID] "
                + "    ,[Name] "
                + "    ,[Surname] "
                + "    ,[PhoneNumber] "
                + "    ,[EmailAddress] "
                + "    ,[Address] "
                + "    ,[Description] "
                + "FROM "
                + "     [dbo].[Parents] "
                + "WHERE "
                + "     [ParentID] = @ParentID "
                + "";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.CommandType = CommandType.Text;
            selectCommand.Parameters.AddWithValue("@ParentID", dbo_ParentsPara.ParentID);
            try
            {
                connection.Open();
                SqlDataReader reader
                    = selectCommand.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    dbo_Parents.ParentID = System.Convert.ToInt32(reader["ParentID"]);
                    dbo_Parents.Name = reader["Name"] is DBNull ? null : reader["Name"].ToString();
                    dbo_Parents.Surname = reader["Surname"] is DBNull ? null : reader["Surname"].ToString();
                    dbo_Parents.PhoneNumber = reader["PhoneNumber"] is DBNull ? null : reader["PhoneNumber"].ToString();
                    dbo_Parents.EmailAddress = reader["EmailAddress"] is DBNull ? null : reader["EmailAddress"].ToString();
                    dbo_Parents.Address = reader["Address"] is DBNull ? null : reader["Address"].ToString();
                    dbo_Parents.Description = reader["Description"] is DBNull ? null : reader["Description"].ToString();
                }
                else
                {
                    dbo_Parents = null;
                }
                reader.Close();
            }
            catch (SqlException)
            {
                return dbo_Parents;
            }
            finally
            {
                connection.Close();
            }
            return dbo_Parents;
        }

        public static bool Add(dbo_Parents dbo_Parents)
        {
            SqlConnection connection = PaulData.GetConnection();
            string insertStatement
                = "INSERT " 
                + "     [dbo].[Parents] "
                + "     ( "
                + "     [Name] "
                + "    ,[Surname] "
                + "    ,[PhoneNumber] "
                + "    ,[EmailAddress] "
                + "    ,[Address] "
                + "    ,[Description] "
                + "     ) "
                + "VALUES " 
                + "     ( "
                + "     @Name "
                + "    ,@Surname "
                + "    ,@PhoneNumber "
                + "    ,@EmailAddress "
                + "    ,@Address "
                + "    ,@Description "
                + "     ) "
                + "";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.CommandType = CommandType.Text;
            if (dbo_Parents.Name != null) {
                insertCommand.Parameters.AddWithValue("@Name", dbo_Parents.Name);
            } else {
                insertCommand.Parameters.AddWithValue("@Name", DBNull.Value); }
            if (dbo_Parents.Surname != null) {
                insertCommand.Parameters.AddWithValue("@Surname", dbo_Parents.Surname);
            } else {
                insertCommand.Parameters.AddWithValue("@Surname", DBNull.Value); }
            if (dbo_Parents.PhoneNumber != null) {
                insertCommand.Parameters.AddWithValue("@PhoneNumber", dbo_Parents.PhoneNumber);
            } else {
                insertCommand.Parameters.AddWithValue("@PhoneNumber", DBNull.Value); }
            if (dbo_Parents.EmailAddress != null) {
                insertCommand.Parameters.AddWithValue("@EmailAddress", dbo_Parents.EmailAddress);
            } else {
                insertCommand.Parameters.AddWithValue("@EmailAddress", DBNull.Value); }
            if (dbo_Parents.Address != null) {
                insertCommand.Parameters.AddWithValue("@Address", dbo_Parents.Address);
            } else {
                insertCommand.Parameters.AddWithValue("@Address", DBNull.Value); }
            if (dbo_Parents.Description != null) {
                insertCommand.Parameters.AddWithValue("@Description", dbo_Parents.Description);
            } else {
                insertCommand.Parameters.AddWithValue("@Description", DBNull.Value); }
            try
            {
                connection.Open();
                int count = insertCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool Update(dbo_Parents oldParents, 
               dbo_Parents newParents)
        {
            SqlConnection connection = PaulData.GetConnection();
            string updateStatement
                = "UPDATE "  
                + "     [dbo].[Parents] "
                + "SET "
                + "     [Name] = @NewName "
                + "    ,[Surname] = @NewSurname "
                + "    ,[PhoneNumber] = @NewPhoneNumber "
                + "    ,[EmailAddress] = @NewEmailAddress "
                + "    ,[Address] = @NewAddress "
                + "    ,[Description] = @NewDescription "
                + "WHERE "
                + "     [ParentID] = @OldParentID " 
                + " AND ((@OldName IS NULL AND [Name] IS NULL) OR [Name] = @OldName) " 
                + " AND ((@OldSurname IS NULL AND [Surname] IS NULL) OR [Surname] = @OldSurname) " 
                + " AND ((@OldPhoneNumber IS NULL AND [PhoneNumber] IS NULL) OR [PhoneNumber] = @OldPhoneNumber) " 
                + " AND ((@OldEmailAddress IS NULL AND [EmailAddress] IS NULL) OR [EmailAddress] = @OldEmailAddress) " 
                + " AND ((@OldAddress IS NULL AND [Address] IS NULL) OR [Address] = @OldAddress) " 
                + " AND ((@OldDescription IS NULL AND [Description] IS NULL) OR [Description] = @OldDescription) " 
                + "";
            SqlCommand updateCommand = new SqlCommand(updateStatement, connection);
            updateCommand.CommandType = CommandType.Text;
            if (newParents.Name != null) {
                updateCommand.Parameters.AddWithValue("@NewName", newParents.Name);
            } else {
                updateCommand.Parameters.AddWithValue("@NewName", DBNull.Value); }
            if (newParents.Surname != null) {
                updateCommand.Parameters.AddWithValue("@NewSurname", newParents.Surname);
            } else {
                updateCommand.Parameters.AddWithValue("@NewSurname", DBNull.Value); }
            if (newParents.PhoneNumber != null) {
                updateCommand.Parameters.AddWithValue("@NewPhoneNumber", newParents.PhoneNumber);
            } else {
                updateCommand.Parameters.AddWithValue("@NewPhoneNumber", DBNull.Value); }
            if (newParents.EmailAddress != null) {
                updateCommand.Parameters.AddWithValue("@NewEmailAddress", newParents.EmailAddress);
            } else {
                updateCommand.Parameters.AddWithValue("@NewEmailAddress", DBNull.Value); }
            if (newParents.Address != null) {
                updateCommand.Parameters.AddWithValue("@NewAddress", newParents.Address);
            } else {
                updateCommand.Parameters.AddWithValue("@NewAddress", DBNull.Value); }
            if (newParents.Description != null) {
                updateCommand.Parameters.AddWithValue("@NewDescription", newParents.Description);
            } else {
                updateCommand.Parameters.AddWithValue("@NewDescription", DBNull.Value); }
            updateCommand.Parameters.AddWithValue("@OldParentID", oldParents.ParentID);
            if (oldParents.Name != null) {
                updateCommand.Parameters.AddWithValue("@OldName", oldParents.Name);
            } else {
                updateCommand.Parameters.AddWithValue("@OldName", DBNull.Value); }
            if (oldParents.Surname != null) {
                updateCommand.Parameters.AddWithValue("@OldSurname", oldParents.Surname);
            } else {
                updateCommand.Parameters.AddWithValue("@OldSurname", DBNull.Value); }
            if (oldParents.PhoneNumber != null) {
                updateCommand.Parameters.AddWithValue("@OldPhoneNumber", oldParents.PhoneNumber);
            } else {
                updateCommand.Parameters.AddWithValue("@OldPhoneNumber", DBNull.Value); }
            if (oldParents.EmailAddress != null) {
                updateCommand.Parameters.AddWithValue("@OldEmailAddress", oldParents.EmailAddress);
            } else {
                updateCommand.Parameters.AddWithValue("@OldEmailAddress", DBNull.Value); }
            if (oldParents.Address != null) {
                updateCommand.Parameters.AddWithValue("@OldAddress", oldParents.Address);
            } else {
                updateCommand.Parameters.AddWithValue("@OldAddress", DBNull.Value); }
            if (oldParents.Description != null) {
                updateCommand.Parameters.AddWithValue("@OldDescription", oldParents.Description);
            } else {
                updateCommand.Parameters.AddWithValue("@OldDescription", DBNull.Value); }
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool Delete(dbo_Parents dbo_Parents)
        {
            SqlConnection connection = PaulData.GetConnection();
            string deleteStatement
                = "DELETE FROM "  
                + "     [dbo].[Parents] "
                + "WHERE " 
                + "     [ParentID] = @OldParentID " 
                + " AND ((@OldName IS NULL AND [Name] IS NULL) OR [Name] = @OldName) " 
                + " AND ((@OldSurname IS NULL AND [Surname] IS NULL) OR [Surname] = @OldSurname) " 
                + " AND ((@OldPhoneNumber IS NULL AND [PhoneNumber] IS NULL) OR [PhoneNumber] = @OldPhoneNumber) " 
                + " AND ((@OldEmailAddress IS NULL AND [EmailAddress] IS NULL) OR [EmailAddress] = @OldEmailAddress) " 
                + " AND ((@OldAddress IS NULL AND [Address] IS NULL) OR [Address] = @OldAddress) " 
                + " AND ((@OldDescription IS NULL AND [Description] IS NULL) OR [Description] = @OldDescription) " 
                + "";
            SqlCommand deleteCommand = new SqlCommand(deleteStatement, connection);
            deleteCommand.CommandType = CommandType.Text;
            deleteCommand.Parameters.AddWithValue("@OldParentID", dbo_Parents.ParentID);
            if (dbo_Parents.Name != null) {
                deleteCommand.Parameters.AddWithValue("@OldName", dbo_Parents.Name);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldName", DBNull.Value); }
            if (dbo_Parents.Surname != null) {
                deleteCommand.Parameters.AddWithValue("@OldSurname", dbo_Parents.Surname);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldSurname", DBNull.Value); }
            if (dbo_Parents.PhoneNumber != null) {
                deleteCommand.Parameters.AddWithValue("@OldPhoneNumber", dbo_Parents.PhoneNumber);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldPhoneNumber", DBNull.Value); }
            if (dbo_Parents.EmailAddress != null) {
                deleteCommand.Parameters.AddWithValue("@OldEmailAddress", dbo_Parents.EmailAddress);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldEmailAddress", DBNull.Value); }
            if (dbo_Parents.Address != null) {
                deleteCommand.Parameters.AddWithValue("@OldAddress", dbo_Parents.Address);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldAddress", DBNull.Value); }
            if (dbo_Parents.Description != null) {
                deleteCommand.Parameters.AddWithValue("@OldDescription", dbo_Parents.Description);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldDescription", DBNull.Value); }
            try
            {
                connection.Open();
                int count = deleteCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
 
