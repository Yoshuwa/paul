using System;
using System.Data;
using System.Data.SqlClient;

namespace Paul.Data
{
    public class PaulData
    {
        public static string connectionString
                = "Data Source=DESKTOP-KL6Q6PT\\SQLEXPRESS;Initial Catalog=Paul;Integrated Security=SSPI;";

        public static SqlConnection GetConnection()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }
    }
}



 
