using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using Paul.Models;

namespace Paul.Data
{

    public class dbo_Students_ParentsData
    {
        public static DataTable SelectAll()
        {
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement 
                = "SELECT "  
                + "     [ParentID] " 
                + "    ,[Name] " 
                + "FROM " 
                + "     [dbo].[Parents] " 
                + "";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            DataTable dt = new DataTable();
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                if (reader.HasRows) {
                    dt.Load(reader); }
                reader.Close();
            }
            catch (SqlException)
            {
                return dt;
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static List<dbo_Parents> List()
        {
            List<dbo_Parents> dbo_ParentsList = new List<dbo_Parents>();
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement 
                = "SELECT "  
                + "     [ParentID] " 
                + "    ,[Name] " 
                + "FROM " 
                + "     [dbo].[Parents] " 
                + "";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                dbo_Parents dbo_Parents = new dbo_Parents();
                while (reader.Read())
                {
                    dbo_Parents = new dbo_Parents();
                    dbo_Parents.ParentID = System.Convert.ToInt32(reader["ParentID"]);
                    dbo_Parents.Name = Convert.ToString(reader["Name"]);
                    dbo_ParentsList.Add(dbo_Parents);
                }
                reader.Close();
            }
            catch (SqlException)
            {
                return dbo_ParentsList;
            }
            finally
            {
                connection.Close();
            }
            return dbo_ParentsList;
        }

    }

}

 
