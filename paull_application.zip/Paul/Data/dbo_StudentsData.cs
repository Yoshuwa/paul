using System;
using System.Data;
using System.Data.SqlClient;
using Paul.Models;

namespace Paul.Data
{
    public class dbo_StudentsData
    {

        public static DataTable SelectAll()
        {
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement
                = "SELECT "  
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.CommandType = CommandType.Text;
            DataTable dt = new DataTable();
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                if (reader.HasRows) {
                    dt.Load(reader); }
                reader.Close();
            }
            catch (SqlException)
            {
                return dt;
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static DataTable Search(string sField, string sCondition, string sValue)
        {
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement = "";
            if (sCondition == "Contains") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "LEFT JOIN [dbo].[Parents] ON [dbo].[Students].[ParentID] = [dbo].[Parents].[ParentID] "
                    + "WHERE " 
                    + "     (@StudentID IS NULL OR @StudentID = '' OR [Students].[StudentID] LIKE '%' + LTRIM(RTRIM(@StudentID)) + '%') " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Students].[Name] LIKE '%' + LTRIM(RTRIM(@Name)) + '%') " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Students].[Surname] LIKE '%' + LTRIM(RTRIM(@Surname)) + '%') " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [dbo].[Parents].[Name] LIKE '%' + LTRIM(RTRIM(@Name)) + '%') " 
                    + "";
            } else if (sCondition == "Equals") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "LEFT JOIN [dbo].[Parents] ON [dbo].[Students].[ParentID] = [dbo].[Parents].[ParentID] "
                    + "WHERE " 
                    + "     (@StudentID IS NULL OR @StudentID = '' OR [Students].[StudentID] = LTRIM(RTRIM(@StudentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Students].[Name] = LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Students].[Surname] = LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [dbo].[Parents].[Name] = LTRIM(RTRIM(@Name))) " 
                    + "";
            } else if  (sCondition == "Starts with...") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "LEFT JOIN [dbo].[Parents] ON [dbo].[Students].[ParentID] = [dbo].[Parents].[ParentID] "
                    + "WHERE " 
                    + "     (@StudentID IS NULL OR @StudentID = '' OR [Students].[StudentID] LIKE LTRIM(RTRIM(@StudentID)) + '%') " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Students].[Name] LIKE LTRIM(RTRIM(@Name)) + '%') " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Students].[Surname] LIKE LTRIM(RTRIM(@Surname)) + '%') " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [dbo].[Parents].[Name] LIKE LTRIM(RTRIM(@Name)) + '%') " 
                    + "";
            } else if  (sCondition == "More than...") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "LEFT JOIN [dbo].[Parents] ON [dbo].[Students].[ParentID] = [dbo].[Parents].[ParentID] "
                    + "WHERE " 
                    + "     (@StudentID IS NULL OR @StudentID = '' OR [Students].[StudentID] > LTRIM(RTRIM(@StudentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Students].[Name] > LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Students].[Surname] > LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [dbo].[Parents].[Name] > LTRIM(RTRIM(@Name))) " 
                    + "";
            } else if  (sCondition == "Less than...") {
                selectStatement
                    = "SELECT " 
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "LEFT JOIN [dbo].[Parents] ON [dbo].[Students].[ParentID] = [dbo].[Parents].[ParentID] "
                    + "WHERE " 
                    + "     (@StudentID IS NULL OR @StudentID = '' OR [Students].[StudentID] < LTRIM(RTRIM(@StudentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Students].[Name] < LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Students].[Surname] < LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [dbo].[Parents].[Name] < LTRIM(RTRIM(@Name))) " 
                    + "";
            } else if  (sCondition == "Equal or more than...") {
                selectStatement
                    = "SELECT "
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "LEFT JOIN [dbo].[Parents] ON [dbo].[Students].[ParentID] = [dbo].[Parents].[ParentID] "
                    + "WHERE " 
                    + "     (@StudentID IS NULL OR @StudentID = '' OR [Students].[StudentID] >= LTRIM(RTRIM(@StudentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Students].[Name] >= LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Students].[Surname] >= LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [dbo].[Parents].[Name] >= LTRIM(RTRIM(@Name))) " 
                    + "";
            } else if (sCondition == "Equal or less than...") {
                selectStatement 
                    = "SELECT "
                + "     [dbo].[Students].[StudentID] "
                + "    ,[dbo].[Students].[Name] "
                + "    ,[dbo].[Students].[Surname] "
                + "    ,[dbo].[Students].[ParentID] "
                + "FROM " 
                + "     [dbo].[Students] " 
                + "LEFT JOIN [dbo].[Parents] ON [dbo].[Students].[ParentID] = [dbo].[Parents].[ParentID] "
                    + "WHERE " 
                    + "     (@StudentID IS NULL OR @StudentID = '' OR [Students].[StudentID] <= LTRIM(RTRIM(@StudentID))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [Students].[Name] <= LTRIM(RTRIM(@Name))) " 
                    + "AND   (@Surname IS NULL OR @Surname = '' OR [Students].[Surname] <= LTRIM(RTRIM(@Surname))) " 
                    + "AND   (@Name IS NULL OR @Name = '' OR [dbo].[Parents].[Name] <= LTRIM(RTRIM(@Name))) " 
                    + "";
            }
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.CommandType = CommandType.Text;
            if (sField == "Student I D") {
                selectCommand.Parameters.AddWithValue("@StudentID", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@StudentID", DBNull.Value); }
            if (sField == "Name") {
                selectCommand.Parameters.AddWithValue("@Name", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@Name", DBNull.Value); }
            if (sField == "Surname") {
                selectCommand.Parameters.AddWithValue("@Surname", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@Surname", DBNull.Value); }
            if (sField == "Parent I D") {
                selectCommand.Parameters.AddWithValue("@Name", sValue);
            } else {
                selectCommand.Parameters.AddWithValue("@Name", DBNull.Value); }
            DataTable dt = new DataTable();
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader();
                if (reader.HasRows) {
                    dt.Load(reader); }
                reader.Close();
            }
            catch (SqlException)
            {
                return dt;
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static dbo_Students Select_Record(dbo_Students dbo_StudentsPara)
        {
        dbo_Students dbo_Students = new dbo_Students();
            SqlConnection connection = PaulData.GetConnection();
            string selectStatement
            = "SELECT " 
                + "     [StudentID] "
                + "    ,[Name] "
                + "    ,[Surname] "
                + "    ,[ParentID] "
                + "FROM "
                + "     [dbo].[Students] "
                + "WHERE "
                + "     [StudentID] = @StudentID "
                + "";
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            selectCommand.CommandType = CommandType.Text;
            selectCommand.Parameters.AddWithValue("@StudentID", dbo_StudentsPara.StudentID);
            try
            {
                connection.Open();
                SqlDataReader reader
                    = selectCommand.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.Read())
                {
                    dbo_Students.StudentID = System.Convert.ToInt32(reader["StudentID"]);
                    dbo_Students.Name = reader["Name"] is DBNull ? null : reader["Name"].ToString();
                    dbo_Students.Surname = reader["Surname"] is DBNull ? null : reader["Surname"].ToString();
                    dbo_Students.ParentID = reader["ParentID"] is DBNull ? null : (Int32?)reader["ParentID"];
                }
                else
                {
                    dbo_Students = null;
                }
                reader.Close();
            }
            catch (SqlException)
            {
                return dbo_Students;
            }
            finally
            {
                connection.Close();
            }
            return dbo_Students;
        }

        public static bool Add(dbo_Students dbo_Students)
        {
            SqlConnection connection = PaulData.GetConnection();
            string insertStatement
                = "INSERT " 
                + "     [dbo].[Students] "
                + "     ( "
                + "     [Name] "
                + "    ,[Surname] "
                + "    ,[ParentID] "
                + "     ) "
                + "VALUES " 
                + "     ( "
                + "     @Name "
                + "    ,@Surname "
                + "    ,@ParentID "
                + "     ) "
                + "";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.CommandType = CommandType.Text;
            if (dbo_Students.Name != null) {
                insertCommand.Parameters.AddWithValue("@Name", dbo_Students.Name);
            } else {
                insertCommand.Parameters.AddWithValue("@Name", DBNull.Value); }
            if (dbo_Students.Surname != null) {
                insertCommand.Parameters.AddWithValue("@Surname", dbo_Students.Surname);
            } else {
                insertCommand.Parameters.AddWithValue("@Surname", DBNull.Value); }
            if (dbo_Students.ParentID.HasValue == true) {
                insertCommand.Parameters.AddWithValue("@ParentID", dbo_Students.ParentID);
            } else {
                insertCommand.Parameters.AddWithValue("@ParentID", DBNull.Value); }
            try
            {
                connection.Open();
                int count = insertCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool Update(dbo_Students oldStudents, 
               dbo_Students newStudents)
        {
            SqlConnection connection = PaulData.GetConnection();
            string updateStatement
                = "UPDATE "  
                + "     [dbo].[Students] "
                + "SET "
                + "     [Name] = @NewName "
                + "    ,[Surname] = @NewSurname "
                + "    ,[ParentID] = @NewParentID "
                + "WHERE "
                + "     [StudentID] = @OldStudentID " 
                + " AND ((@OldName IS NULL AND [Name] IS NULL) OR [Name] = @OldName) " 
                + " AND ((@OldSurname IS NULL AND [Surname] IS NULL) OR [Surname] = @OldSurname) " 
                + " AND ((@OldParentID IS NULL AND [ParentID] IS NULL) OR [ParentID] = @OldParentID) " 
                + "";
            SqlCommand updateCommand = new SqlCommand(updateStatement, connection);
            updateCommand.CommandType = CommandType.Text;
            if (newStudents.Name != null) {
                updateCommand.Parameters.AddWithValue("@NewName", newStudents.Name);
            } else {
                updateCommand.Parameters.AddWithValue("@NewName", DBNull.Value); }
            if (newStudents.Surname != null) {
                updateCommand.Parameters.AddWithValue("@NewSurname", newStudents.Surname);
            } else {
                updateCommand.Parameters.AddWithValue("@NewSurname", DBNull.Value); }
            if (newStudents.ParentID.HasValue == true) {
                updateCommand.Parameters.AddWithValue("@NewParentID", newStudents.ParentID);
            } else {
                updateCommand.Parameters.AddWithValue("@NewParentID", DBNull.Value); }
            updateCommand.Parameters.AddWithValue("@OldStudentID", oldStudents.StudentID);
            if (oldStudents.Name != null) {
                updateCommand.Parameters.AddWithValue("@OldName", oldStudents.Name);
            } else {
                updateCommand.Parameters.AddWithValue("@OldName", DBNull.Value); }
            if (oldStudents.Surname != null) {
                updateCommand.Parameters.AddWithValue("@OldSurname", oldStudents.Surname);
            } else {
                updateCommand.Parameters.AddWithValue("@OldSurname", DBNull.Value); }
            if (oldStudents.ParentID.HasValue == true) {
                updateCommand.Parameters.AddWithValue("@OldParentID", oldStudents.ParentID);
            } else {
                updateCommand.Parameters.AddWithValue("@OldParentID", DBNull.Value); }
            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public static bool Delete(dbo_Students dbo_Students)
        {
            SqlConnection connection = PaulData.GetConnection();
            string deleteStatement
                = "DELETE FROM "  
                + "     [dbo].[Students] "
                + "WHERE " 
                + "     [StudentID] = @OldStudentID " 
                + " AND ((@OldName IS NULL AND [Name] IS NULL) OR [Name] = @OldName) " 
                + " AND ((@OldSurname IS NULL AND [Surname] IS NULL) OR [Surname] = @OldSurname) " 
                + " AND ((@OldParentID IS NULL AND [ParentID] IS NULL) OR [ParentID] = @OldParentID) " 
                + "";
            SqlCommand deleteCommand = new SqlCommand(deleteStatement, connection);
            deleteCommand.CommandType = CommandType.Text;
            deleteCommand.Parameters.AddWithValue("@OldStudentID", dbo_Students.StudentID);
            if (dbo_Students.Name != null) {
                deleteCommand.Parameters.AddWithValue("@OldName", dbo_Students.Name);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldName", DBNull.Value); }
            if (dbo_Students.Surname != null) {
                deleteCommand.Parameters.AddWithValue("@OldSurname", dbo_Students.Surname);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldSurname", DBNull.Value); }
            if (dbo_Students.ParentID.HasValue == true) {
                deleteCommand.Parameters.AddWithValue("@OldParentID", dbo_Students.ParentID);
            } else {
                deleteCommand.Parameters.AddWithValue("@OldParentID", DBNull.Value); }
            try
            {
                connection.Open();
                int count = deleteCommand.ExecuteNonQuery();
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
 
