using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Paul.Startup))]
namespace Paul
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
 
