using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace Paul.Models
{
    [Table("Parents", Schema="dbo")]
    public class dbo_Parents
    {
        [Key]
        [Column(Order = 0)]
        [Required]
        [Display(Name = "Parent I D")]
        public Int32 ParentID { get; set; }

        [StringLength(50)]
        [Display(Name = "Name")]
        public String Name { get; set; }

        [StringLength(50)]
        [Display(Name = "Surname")]
        public String Surname { get; set; }

        [StringLength(50)]
        [Display(Name = "Phone Number")]
        public String PhoneNumber { get; set; }

        [StringLength(50)]
        [Display(Name = "Email Address")]
        public String EmailAddress { get; set; }

        [StringLength(50)]
        [Display(Name = "Address")]
        public String Address { get; set; }

        [StringLength(4000)]
        [Display(Name = "Description")]
        public String Description { get; set; }


    }
}
 
