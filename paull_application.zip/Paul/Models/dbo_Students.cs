using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace Paul.Models
{
    [Table("Students", Schema="dbo")]
    public class dbo_Students
    {
        [Key]
        [Column(Order = 0)]
        [Required]
        [Display(Name = "Student I D")]
        public Int32 StudentID { get; set; }

        [StringLength(50)]
        [Display(Name = "Name")]
        public String Name { get; set; }

        [StringLength(50)]
        [Display(Name = "Surname")]
        public String Surname { get; set; }

        [Display(Name = "Parent I D")]
        public Int32? ParentID { get; set; }

        // ComboBox
        public virtual dbo_Parents dbo_Parents { get; set; }

    }
}
 
