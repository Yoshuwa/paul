using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.UI;
using PagedList;
using PagedList.Mvc;
using MigraDoc.DocumentObjectModel;
using MigraDoc.Rendering;
using Paul.Models;
using Paul.Data;

namespace Paul.Controllers
{
    public class dbo_ParentsController : Controller
    {

        DataTable dtParents = new DataTable();

        // GET: /dbo_Parents/
        public ActionResult Index(string sortOrder,  
                                  String SearchField,
                                  String SearchCondition,
                                  String SearchText,
                                  String Export,
                                  int? PageSize,
                                  int? page, 
                                  string command)
        {

            if (command == "Show All") {
                SearchField = null;
                SearchCondition = null;
                SearchText = null;
                Session["SearchField"] = null;
                Session["SearchCondition"] = null;
                Session["SearchText"] = null; } 
            else if (command == "Add New Record") { return RedirectToAction("Create"); } 
            else if (command == "Export") { Session["Export"] = Export; } 
            else if (command == "Search" | command == "Page Size") {
                if (!string.IsNullOrEmpty(SearchText)) {
                    Session["SearchField"] = SearchField;
                    Session["SearchCondition"] = SearchCondition;
                    Session["SearchText"] = SearchText; }
                } 
            if (command == "Page Size") { Session["PageSize"] = PageSize; }

            ViewData["SearchFields"] = GetFields((Session["SearchField"] == null ? "Parent I D" : Convert.ToString(Session["SearchField"])));
            ViewData["SearchConditions"] = Library.GetConditions((Session["SearchCondition"] == null ? "Contains" : Convert.ToString(Session["SearchCondition"])));
            ViewData["SearchText"] = Session["SearchText"];
            ViewData["Exports"] = Library.GetExports((Session["Export"] == null ? "Pdf" : Convert.ToString(Session["Export"])));
            ViewData["PageSizes"] = Library.GetPageSizes();

            ViewData["CurrentSort"] = sortOrder;
            ViewData["ParentIDSortParm"] = sortOrder == "ParentID_asc" ? "ParentID_desc" : "ParentID_asc";
            ViewData["NameSortParm"] = sortOrder == "Name_asc" ? "Name_desc" : "Name_asc";
            ViewData["SurnameSortParm"] = sortOrder == "Surname_asc" ? "Surname_desc" : "Surname_asc";
            ViewData["PhoneNumberSortParm"] = sortOrder == "PhoneNumber_asc" ? "PhoneNumber_desc" : "PhoneNumber_asc";
            ViewData["EmailAddressSortParm"] = sortOrder == "EmailAddress_asc" ? "EmailAddress_desc" : "EmailAddress_asc";
            ViewData["AddressSortParm"] = sortOrder == "Address_asc" ? "Address_desc" : "Address_asc";
            ViewData["DescriptionSortParm"] = sortOrder == "Description_asc" ? "Description_desc" : "Description_asc";

            dtParents = dbo_ParentsData.SelectAll();

            try
            {
                if (!string.IsNullOrEmpty(Convert.ToString(Session["SearchField"])) & !string.IsNullOrEmpty(Convert.ToString(Session["SearchCondition"])) & !string.IsNullOrEmpty(Convert.ToString(Session["SearchText"])))
                {
                    dtParents = dbo_ParentsData.Search(Convert.ToString(Session["SearchField"]), Convert.ToString(Session["SearchCondition"]), Convert.ToString(Session["SearchText"]));
                }
            }
            catch { }

            var Query = from rowParents in dtParents.AsEnumerable()
                        select new dbo_Parents() {
                            ParentID = rowParents.Field<Int32>("ParentID")
                           ,Name = rowParents.Field<String>("Name")
                           ,Surname = rowParents.Field<String>("Surname")
                           ,PhoneNumber = rowParents.Field<String>("PhoneNumber")
                           ,EmailAddress = rowParents.Field<String>("EmailAddress")
                           ,Address = rowParents.Field<String>("Address")
                           ,Description = rowParents.Field<String>("Description")
                        };

            switch (sortOrder)
            {
                case "ParentID_desc":
                    Query = Query.OrderByDescending(s => s.ParentID);
                    break;
                case "ParentID_asc":
                    Query = Query.OrderBy(s => s.ParentID);
                    break;
                case "Name_desc":
                    Query = Query.OrderByDescending(s => s.Name);
                    break;
                case "Name_asc":
                    Query = Query.OrderBy(s => s.Name);
                    break;
                case "Surname_desc":
                    Query = Query.OrderByDescending(s => s.Surname);
                    break;
                case "Surname_asc":
                    Query = Query.OrderBy(s => s.Surname);
                    break;
                case "PhoneNumber_desc":
                    Query = Query.OrderByDescending(s => s.PhoneNumber);
                    break;
                case "PhoneNumber_asc":
                    Query = Query.OrderBy(s => s.PhoneNumber);
                    break;
                case "EmailAddress_desc":
                    Query = Query.OrderByDescending(s => s.EmailAddress);
                    break;
                case "EmailAddress_asc":
                    Query = Query.OrderBy(s => s.EmailAddress);
                    break;
                case "Address_desc":
                    Query = Query.OrderByDescending(s => s.Address);
                    break;
                case "Address_asc":
                    Query = Query.OrderBy(s => s.Address);
                    break;
                case "Description_desc":
                    Query = Query.OrderByDescending(s => s.Description);
                    break;
                case "Description_asc":
                    Query = Query.OrderBy(s => s.Description);
                    break;
                default:  // Name ascending 
                    Query = Query.OrderBy(s => s.ParentID);
                    break;
            }

            if (command == "Export") {
                GridView gv = new GridView();
                DataTable dt = new DataTable();
                dt.Columns.Add("Parent I D", typeof(string));
                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("Surname", typeof(string));
                dt.Columns.Add("Phone Number", typeof(string));
                dt.Columns.Add("Email Address", typeof(string));
                dt.Columns.Add("Address", typeof(string));
                dt.Columns.Add("Description", typeof(string));
                foreach (var item in Query)
                {
                    dt.Rows.Add(
                        item.ParentID
                       ,item.Name
                       ,item.Surname
                       ,item.PhoneNumber
                       ,item.EmailAddress
                       ,item.Address
                       ,item.Description
                    );
                }
                gv.DataSource = dt;
                gv.DataBind();
                ExportData(Export, gv, dt);
            }

            int pageNumber = (page ?? 1);
            int? pageSZ = (Convert.ToInt32(Session["PageSize"]) == 0 ? 5 : Convert.ToInt32(Session["PageSize"]));
            return View(Query.ToPagedList(pageNumber, (pageSZ ?? 5)));
        }

        // GET: /dbo_Parents/Details/<id>
        public ActionResult Details(
                                      Int32? ParentID
                                   )
        {
            if (
                    ParentID == null
               )
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }


            dbo_Parents dbo_Parents = new dbo_Parents();
            dbo_Parents.ParentID = System.Convert.ToInt32(ParentID);
            dbo_Parents = dbo_ParentsData.Select_Record(dbo_Parents);

            if (dbo_Parents == null)
            {
                return HttpNotFound();
            }
            return View(dbo_Parents);
        }

        // GET: /dbo_Parents/Create
        public ActionResult Create()
        {

            return View();
        }

        // POST: /dbo_Parents/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include=
				           "Name"
				   + "," + "Surname"
				   + "," + "PhoneNumber"
				   + "," + "EmailAddress"
				   + "," + "Address"
				   + "," + "Description"
				  )] dbo_Parents dbo_Parents)
        {
            if (ModelState.IsValid)
            {
                bool bSucess = false;
                bSucess = dbo_ParentsData.Add(dbo_Parents);
                if (bSucess == true)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Can Not Insert");
                }
            }

            return View(dbo_Parents);
        }

        // GET: /dbo_Parents/Edit/<id>
        public ActionResult Edit(
                                   Int32? ParentID
                                )
        {
            if (
                    ParentID == null
               )
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            dbo_Parents dbo_Parents = new dbo_Parents();
            dbo_Parents.ParentID = System.Convert.ToInt32(ParentID);
            dbo_Parents = dbo_ParentsData.Select_Record(dbo_Parents);

            if (dbo_Parents == null)
            {
                return HttpNotFound();
            }

            return View(dbo_Parents);
        }

        // POST: /dbo_Parents/Edit/<id>
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(dbo_Parents dbo_Parents)
        {

            dbo_Parents odbo_Parents = new dbo_Parents();
            odbo_Parents.ParentID = System.Convert.ToInt32(dbo_Parents.ParentID);
            odbo_Parents = dbo_ParentsData.Select_Record(dbo_Parents);

            if (ModelState.IsValid)
            {
                bool bSucess = false;
                bSucess = dbo_ParentsData.Update(odbo_Parents, dbo_Parents);
                if (bSucess == true)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Can Not Update");
                }
            }

            return View(dbo_Parents);
        }

        // GET: /dbo_Parents/Delete/<id>
        public ActionResult Delete(
                                     Int32? ParentID
                                  )
        {
            if (
                    ParentID == null
               )
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }


            dbo_Parents dbo_Parents = new dbo_Parents();
            dbo_Parents.ParentID = System.Convert.ToInt32(ParentID);
            dbo_Parents = dbo_ParentsData.Select_Record(dbo_Parents);

            if (dbo_Parents == null)
            {
                return HttpNotFound();
            }
            return View(dbo_Parents);
        }

        // POST: /dbo_Parents/Delete/<id>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(
                                            Int32? ParentID
                                            )
        {

            dbo_Parents dbo_Parents = new dbo_Parents();
            dbo_Parents.ParentID = System.Convert.ToInt32(ParentID);
            dbo_Parents = dbo_ParentsData.Select_Record(dbo_Parents);

            bool bSucess = false;
            bSucess = dbo_ParentsData.Delete(dbo_Parents);
            if (bSucess == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", "Can Not Delete");
            }
            return null;
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        private static List<SelectListItem> GetFields(String select)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            SelectListItem Item1 = new SelectListItem { Text = "Parent I D", Value = "Parent I D" };
            SelectListItem Item2 = new SelectListItem { Text = "Name", Value = "Name" };
            SelectListItem Item3 = new SelectListItem { Text = "Surname", Value = "Surname" };
            SelectListItem Item4 = new SelectListItem { Text = "Phone Number", Value = "Phone Number" };
            SelectListItem Item5 = new SelectListItem { Text = "Email Address", Value = "Email Address" };
            SelectListItem Item6 = new SelectListItem { Text = "Address", Value = "Address" };
            SelectListItem Item7 = new SelectListItem { Text = "Description", Value = "Description" };

                 if (select == "Parent I D") { Item1.Selected = true; }
            else if (select == "Name") { Item2.Selected = true; }
            else if (select == "Surname") { Item3.Selected = true; }
            else if (select == "Phone Number") { Item4.Selected = true; }
            else if (select == "Email Address") { Item5.Selected = true; }
            else if (select == "Address") { Item6.Selected = true; }
            else if (select == "Description") { Item7.Selected = true; }

            list.Add(Item1);
            list.Add(Item2);
            list.Add(Item3);
            list.Add(Item4);
            list.Add(Item5);
            list.Add(Item6);
            list.Add(Item7);

            return list.ToList();
        }

        private void ExportData(String Export, GridView gv, DataTable dt)
        {
            if (Export == "Pdf")
            {
                PDFform pdfForm = new PDFform(dt, "Dbo. Parents", "Many");
                Document document = pdfForm.CreateDocument();
                PdfDocumentRenderer renderer = new PdfDocumentRenderer(true);
                renderer.Document = document;
                renderer.RenderDocument();

                MemoryStream stream = new MemoryStream();
                renderer.PdfDocument.Save(stream, false);

                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;filename=" + "Report.pdf");
                Response.ContentType = "application/Pdf.pdf";
                Response.BinaryWrite(stream.ToArray());
                Response.Flush();
                Response.End();
            }
            else
            {
                Response.ClearContent();
                Response.Buffer = true;
                if (Export == "Excel")
                {
                    Response.AddHeader("content-disposition", "attachment;filename=" + "Report.xls");
                    Response.ContentType = "application/Excel.xls";
                }
                else if (Export == "Word")
                {
                    Response.AddHeader("content-disposition", "attachment;filename=" + "Report.doc");
                    Response.ContentType = "application/Word.doc";
                }
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }

    }
}
 
