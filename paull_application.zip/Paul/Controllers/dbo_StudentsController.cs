using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.UI;
using PagedList;
using PagedList.Mvc;
using MigraDoc.DocumentObjectModel;
using MigraDoc.Rendering;
using Paul.Models;
using Paul.Data;

namespace Paul.Controllers
{
    public class dbo_StudentsController : Controller
    {

        DataTable dtStudents = new DataTable();
        DataTable dtParents = new DataTable();

        // GET: /dbo_Students/
        public ActionResult Index(string sortOrder,  
                                  String SearchField,
                                  String SearchCondition,
                                  String SearchText,
                                  String Export,
                                  int? PageSize,
                                  int? page, 
                                  string command)
        {

            if (command == "Show All") {
                SearchField = null;
                SearchCondition = null;
                SearchText = null;
                Session["SearchField"] = null;
                Session["SearchCondition"] = null;
                Session["SearchText"] = null; } 
            else if (command == "Add New Record") { return RedirectToAction("Create"); } 
            else if (command == "Export") { Session["Export"] = Export; } 
            else if (command == "Search" | command == "Page Size") {
                if (!string.IsNullOrEmpty(SearchText)) {
                    Session["SearchField"] = SearchField;
                    Session["SearchCondition"] = SearchCondition;
                    Session["SearchText"] = SearchText; }
                } 
            if (command == "Page Size") { Session["PageSize"] = PageSize; }

            ViewData["SearchFields"] = GetFields((Session["SearchField"] == null ? "Student I D" : Convert.ToString(Session["SearchField"])));
            ViewData["SearchConditions"] = Library.GetConditions((Session["SearchCondition"] == null ? "Contains" : Convert.ToString(Session["SearchCondition"])));
            ViewData["SearchText"] = Session["SearchText"];
            ViewData["Exports"] = Library.GetExports((Session["Export"] == null ? "Pdf" : Convert.ToString(Session["Export"])));
            ViewData["PageSizes"] = Library.GetPageSizes();

            ViewData["CurrentSort"] = sortOrder;
            ViewData["StudentIDSortParm"] = sortOrder == "StudentID_asc" ? "StudentID_desc" : "StudentID_asc";
            ViewData["NameSortParm"] = sortOrder == "Name_asc" ? "Name_desc" : "Name_asc";
            ViewData["SurnameSortParm"] = sortOrder == "Surname_asc" ? "Surname_desc" : "Surname_asc";
            ViewData["ParentIDSortParm"] = sortOrder == "ParentID_asc" ? "ParentID_desc" : "ParentID_asc";

            dtStudents = dbo_StudentsData.SelectAll();
            dtParents = dbo_Students_ParentsData.SelectAll();

            try
            {
                if (!string.IsNullOrEmpty(Convert.ToString(Session["SearchField"])) & !string.IsNullOrEmpty(Convert.ToString(Session["SearchCondition"])) & !string.IsNullOrEmpty(Convert.ToString(Session["SearchText"])))
                {
                    dtStudents = dbo_StudentsData.Search(Convert.ToString(Session["SearchField"]), Convert.ToString(Session["SearchCondition"]), Convert.ToString(Session["SearchText"]));
                }
            }
            catch { }

            var Query = from rowStudents in dtStudents.AsEnumerable()
                        join rowParents in dtParents.AsEnumerable() on rowStudents.Field<Int32?>("ParentID") equals rowParents.Field<Int32>("ParentID")
                        select new dbo_Students() {
                            StudentID = rowStudents.Field<Int32>("StudentID")
                           ,Name = rowStudents.Field<String>("Name")
                           ,Surname = rowStudents.Field<String>("Surname")
                           ,
                            dbo_Parents = new dbo_Parents() 
                            {
                                   ParentID = rowParents.Field<Int32>("ParentID")
                                  ,Name = rowParents.Field<String>("Name")
                            }
                        };

            switch (sortOrder)
            {
                case "StudentID_desc":
                    Query = Query.OrderByDescending(s => s.StudentID);
                    break;
                case "StudentID_asc":
                    Query = Query.OrderBy(s => s.StudentID);
                    break;
                case "Name_desc":
                    Query = Query.OrderByDescending(s => s.Name);
                    break;
                case "Name_asc":
                    Query = Query.OrderBy(s => s.Name);
                    break;
                case "Surname_desc":
                    Query = Query.OrderByDescending(s => s.Surname);
                    break;
                case "Surname_asc":
                    Query = Query.OrderBy(s => s.Surname);
                    break;
                case "ParentID_desc":
                    Query = Query.OrderByDescending(s => s.dbo_Parents.Name);
                    break;
                case "ParentID_asc":
                    Query = Query.OrderBy(s => s.dbo_Parents.Name);
                    break;
                default:  // Name ascending 
                    Query = Query.OrderBy(s => s.StudentID);
                    break;
            }

            if (command == "Export") {
                GridView gv = new GridView();
                DataTable dt = new DataTable();
                dt.Columns.Add("Student I D", typeof(string));
                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("Surname", typeof(string));
                dt.Columns.Add("Parent I D", typeof(string));
                foreach (var item in Query)
                {
                    dt.Rows.Add(
                        item.StudentID
                       ,item.Name
                       ,item.Surname
                       ,item.dbo_Parents.Name
                    );
                }
                gv.DataSource = dt;
                gv.DataBind();
                ExportData(Export, gv, dt);
            }

            int pageNumber = (page ?? 1);
            int? pageSZ = (Convert.ToInt32(Session["PageSize"]) == 0 ? 5 : Convert.ToInt32(Session["PageSize"]));
            return View(Query.ToPagedList(pageNumber, (pageSZ ?? 5)));
        }

        // GET: /dbo_Students/Details/<id>
        public ActionResult Details(
                                      Int32? StudentID
                                   )
        {
            if (
                    StudentID == null
               )
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            dtParents = dbo_Students_ParentsData.SelectAll();

            dbo_Students dbo_Students = new dbo_Students();
            dbo_Students.StudentID = System.Convert.ToInt32(StudentID);
            dbo_Students = dbo_StudentsData.Select_Record(dbo_Students);
            dbo_Students.dbo_Parents = new dbo_Parents()
            {
                ParentID = (Int32)dbo_Students.ParentID
               ,Name = (from DataRow rowParents in dtParents.Rows
                      where dbo_Students.ParentID == (int)rowParents["ParentID"]
                      select (String)rowParents["Name"]).FirstOrDefault()
            };

            if (dbo_Students == null)
            {
                return HttpNotFound();
            }
            return View(dbo_Students);
        }

        // GET: /dbo_Students/Create
        public ActionResult Create()
        {
        // ComboBox
            ViewData["ParentID"] = new SelectList(dbo_Students_ParentsData.List(), "ParentID", "Name");

            return View();
        }

        // POST: /dbo_Students/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include=
				           "Name"
				   + "," + "Surname"
				   + "," + "ParentID"
				  )] dbo_Students dbo_Students)
        {
            if (ModelState.IsValid)
            {
                bool bSucess = false;
                bSucess = dbo_StudentsData.Add(dbo_Students);
                if (bSucess == true)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Can Not Insert");
                }
            }
        // ComboBox
            ViewData["ParentID"] = new SelectList(dbo_Students_ParentsData.List(), "ParentID", "Name", dbo_Students.ParentID);

            return View(dbo_Students);
        }

        // GET: /dbo_Students/Edit/<id>
        public ActionResult Edit(
                                   Int32? StudentID
                                )
        {
            if (
                    StudentID == null
               )
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            dbo_Students dbo_Students = new dbo_Students();
            dbo_Students.StudentID = System.Convert.ToInt32(StudentID);
            dbo_Students = dbo_StudentsData.Select_Record(dbo_Students);

            if (dbo_Students == null)
            {
                return HttpNotFound();
            }
        // ComboBox
            ViewData["ParentID"] = new SelectList(dbo_Students_ParentsData.List(), "ParentID", "Name", dbo_Students.ParentID);

            return View(dbo_Students);
        }

        // POST: /dbo_Students/Edit/<id>
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(dbo_Students dbo_Students)
        {

            dbo_Students odbo_Students = new dbo_Students();
            odbo_Students.StudentID = System.Convert.ToInt32(dbo_Students.StudentID);
            odbo_Students = dbo_StudentsData.Select_Record(dbo_Students);

            if (ModelState.IsValid)
            {
                bool bSucess = false;
                bSucess = dbo_StudentsData.Update(odbo_Students, dbo_Students);
                if (bSucess == true)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Can Not Update");
                }
            }
        // ComboBox
            ViewData["ParentID"] = new SelectList(dbo_Students_ParentsData.List(), "ParentID", "Name", dbo_Students.ParentID);

            return View(dbo_Students);
        }

        // GET: /dbo_Students/Delete/<id>
        public ActionResult Delete(
                                     Int32? StudentID
                                  )
        {
            if (
                    StudentID == null
               )
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            dtParents = dbo_Students_ParentsData.SelectAll();

            dbo_Students dbo_Students = new dbo_Students();
            dbo_Students.StudentID = System.Convert.ToInt32(StudentID);
            dbo_Students = dbo_StudentsData.Select_Record(dbo_Students);
            dbo_Students.dbo_Parents = new dbo_Parents()
            {
                ParentID = (Int32)dbo_Students.ParentID
               ,Name = (from DataRow rowParents in dtParents.Rows
                      where dbo_Students.ParentID == (int)rowParents["ParentID"]
                      select (String)rowParents["Name"]).FirstOrDefault()
            };

            if (dbo_Students == null)
            {
                return HttpNotFound();
            }
            return View(dbo_Students);
        }

        // POST: /dbo_Students/Delete/<id>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(
                                            Int32? StudentID
                                            )
        {

            dbo_Students dbo_Students = new dbo_Students();
            dbo_Students.StudentID = System.Convert.ToInt32(StudentID);
            dbo_Students = dbo_StudentsData.Select_Record(dbo_Students);

            bool bSucess = false;
            bSucess = dbo_StudentsData.Delete(dbo_Students);
            if (bSucess == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", "Can Not Delete");
            }
            return null;
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        private static List<SelectListItem> GetFields(String select)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            SelectListItem Item1 = new SelectListItem { Text = "Student I D", Value = "Student I D" };
            SelectListItem Item2 = new SelectListItem { Text = "Name", Value = "Name" };
            SelectListItem Item3 = new SelectListItem { Text = "Surname", Value = "Surname" };
            SelectListItem Item4 = new SelectListItem { Text = "Parent I D", Value = "Parent I D" };

                 if (select == "Student I D") { Item1.Selected = true; }
            else if (select == "Name") { Item2.Selected = true; }
            else if (select == "Surname") { Item3.Selected = true; }
            else if (select == "Parent I D") { Item4.Selected = true; }

            list.Add(Item1);
            list.Add(Item2);
            list.Add(Item3);
            list.Add(Item4);

            return list.ToList();
        }

        private void ExportData(String Export, GridView gv, DataTable dt)
        {
            if (Export == "Pdf")
            {
                PDFform pdfForm = new PDFform(dt, "Dbo. Students", "Many");
                Document document = pdfForm.CreateDocument();
                PdfDocumentRenderer renderer = new PdfDocumentRenderer(true);
                renderer.Document = document;
                renderer.RenderDocument();

                MemoryStream stream = new MemoryStream();
                renderer.PdfDocument.Save(stream, false);

                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;filename=" + "Report.pdf");
                Response.ContentType = "application/Pdf.pdf";
                Response.BinaryWrite(stream.ToArray());
                Response.Flush();
                Response.End();
            }
            else
            {
                Response.ClearContent();
                Response.Buffer = true;
                if (Export == "Excel")
                {
                    Response.AddHeader("content-disposition", "attachment;filename=" + "Report.xls");
                    Response.ContentType = "application/Excel.xls";
                }
                else if (Export == "Word")
                {
                    Response.AddHeader("content-disposition", "attachment;filename=" + "Report.doc");
                    Response.ContentType = "application/Word.doc";
                }
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }

    }
}
 
